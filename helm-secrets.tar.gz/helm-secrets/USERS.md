# helm-secrets Users

Who’s actually using helm-secrets? The following table is compiled from public information, survey response and PRs. It’s
likely this is only a small selection of actual users, but it’s a start.

If you are using helm-secrets in your company or organization, we would like to invite you to create a PR to add your
information to this file.

| Organization | Workload   | More Info                                                | Location | Added    |
|--------------|------------|----------------------------------------------------------|----------|----------|
| adorsys      | production | Using helm-secrets for production deployments since 2017 | Germany  | Dec 2022 |
