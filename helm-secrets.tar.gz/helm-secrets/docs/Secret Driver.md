Moved to https://github.com/jkroepke/helm-secrets/wiki/Secret%20Backends
