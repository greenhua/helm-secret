# Known Issues

# Compatibility issue between gpg 2.2 and gpg 2.3.

Error:
```
Error decrypting tree: Error walking tree: Could not decrypt value: crypto/aes: invalid key size 0
```
For possible workarounds see [Issue 1](https://github.com/jkroepke/helm-secrets/issues/158) and [Issue 2](https://github.com/mozilla/sops/issues/896)
