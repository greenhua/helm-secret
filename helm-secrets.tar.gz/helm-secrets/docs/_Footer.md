
This wiki is synced with the [`docs`](https://github.com/jkroepke/helm-secrets/tree/main/docs) folder from the code repository! To improve the wiki, create a [pull request](https://github.com/jkroepke/helm-secrets/pulls) against the code repository with the suggested changes.
